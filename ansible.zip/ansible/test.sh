#!/bin/bash
sudo -u postgres psql -c "CREATE DATABASE bd_test;"
