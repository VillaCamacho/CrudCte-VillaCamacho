import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class ParallelExpect {
    public static void main(String[] args) {
        String numIps [] = new String[4];
	numIps[0] = "b20badb976f7";
	numIps[1] = "212e19fc790c";
	numIps[2] = "9cac1809acd0";
	numIps[3] = "f3fb96321cd2";
        ExecutorService executor = Executors.newFixedThreadPool(numIps.length);

        for (int i = 0; i < numIps.length; i++) {
            final int ipNumber = i;
            executor.submit(() -> runExpectScript(numIps[ipNumber]+""));
        }

        executor.shutdown();
        try {
            if (!executor.awaitTermination(1, TimeUnit.HOURS)) {
                executor.shutdownNow();
            }
        } catch (InterruptedException e) {
            executor.shutdownNow();
            Thread.currentThread().interrupt();
        }
    }

    private static void runExpectScript(String ipAddress) {
        try {
            ProcessBuilder processBuilder = new ProcessBuilder("expect", "/etc/ansible/conf_contenedores.exp", ipAddress);
            processBuilder.inheritIO();
            Process process = processBuilder.start();
            process.waitFor();
        } catch (Exception e) {
            System.err.println("Error al ejecutar el script expect para la IP " + ipAddress);
            e.printStackTrace();
        }
    }
}
